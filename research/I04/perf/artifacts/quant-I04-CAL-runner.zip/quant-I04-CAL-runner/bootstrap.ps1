$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

function Find-Python {
  foreach ($c in @("py -3.12", "py -3.11", "python", "python3")) {
    try {
      $parts = $c -split " "
      & $parts[0] $parts[1..($parts.Length-1)] -c "import sys; assert sys.version_info[:2]>=(3,11); print(sys.executable)" 2>$null
      if ($LASTEXITCODE -eq 0) { return $c }
    } catch {}
  }
  return $null
}

$py = Find-Python
if (-not $py) {
  Write-Host "ERROR: Python 3.11+ not found. Install from python.org (user install) then retry."
  exit 1
}
Write-Host "Using launcher: $py"

$venv = Join-Path $PSScriptRoot ".venv"
if (-not (Test-Path $venv)) {
  Write-Host "Will create isolated venv at $venv and install:"
  Get-Content (Join-Path $PSScriptRoot "requirements.lock")
  $ans = Read-Host "Proceed with user-local install? [Y/N]"
  if ($ans -notin @("Y","y")) { exit 2 }
  $parts = $py -split " "
  & $parts[0] $parts[1..($parts.Length-1)] -m venv $venv
}

$venvPy = Join-Path $venv "Scripts\python.exe"
& $venvPy -m pip install --upgrade pip
& $venvPy -m pip install -r (Join-Path $PSScriptRoot "requirements.lock")

$env:PYTHONPATH = (Join-Path $PSScriptRoot "src")
$env:OMP_NUM_THREADS = "1"
$env:MKL_NUM_THREADS = "1"
$env:OPENBLAS_NUM_THREADS = "1"
# Never carry test overrides into canonical portable runs
Remove-Item Env:I04_CAL_ALLOW_TEST_OVERRIDES -ErrorAction SilentlyContinue
if (Test-Path (Join-Path $PSScriptRoot "CODE_COMMIT.txt")) {
  $env:QUANT_I04_CAL_GIT_COMMIT = (Get-Content (Join-Path $PSScriptRoot "CODE_COMMIT.txt") -TotalCount 1).Trim()
}

# Hardware snapshot
$hw = Join-Path $PSScriptRoot "reports\hardware.json"
New-Item -ItemType Directory -Force -Path (Join-Path $PSScriptRoot "reports") | Out-Null
$cpu = Get-CimInstance Win32_Processor | Select-Object -First 1 Name, NumberOfCores, NumberOfLogicalProcessors
$gpu = Get-CimInstance Win32_VideoController | Select-Object Name, AdapterRAM, DriverVersion
$ram = [math]::Round((Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory / 1GB, 2)
@{ cpu = $cpu; gpu = $gpu; ram_gb = $ram; python = (& $venvPy -c "import sys; print(sys.version)") } |
  ConvertTo-Json -Depth 5 | Set-Content -Encoding utf8 $hw

# Workers: leave one logical CPU free
$logical = [int]$cpu.NumberOfLogicalProcessors
if ($logical -lt 1) { $logical = 2 }
$workers = [Math]::Max(1, $logical - 1)

$machine = $env:I04_CAL_MACHINE
if (-not $machine) { $machine = "OPTIPLEX" }
$allow = Join-Path $PSScriptRoot "config\allowlist_$machine.txt"
if (-not (Test-Path $allow)) {
  Write-Host "Missing $allow — set I04_CAL_MACHINE=ASUS or OPTIPLEX, or place allowlist."
  exit 3
}

$out = Join-Path $PSScriptRoot "results\$machine"
New-Item -ItemType Directory -Force -Path $out, (Join-Path $PSScriptRoot "logs"), (Join-Path $PSScriptRoot "checkpoints") | Out-Null

$maxH = 16
if ($env:MAX_RUNTIME_HOURS) { $maxH = [double]$env:MAX_RUNTIME_HOURS }
$margin = 20
if ($env:SHUTDOWN_MARGIN_MINUTES) { $margin = [double]$env:SHUTDOWN_MARGIN_MINUTES }

$resume = @()
if (Test-Path (Join-Path $out "manifest.json")) { $resume = @("--resume") }

Write-Host "Starting I04-CAL machine=$machine workers=$workers max_hours=$maxH margin_min=$margin"
$log = Join-Path $PSScriptRoot ("logs\run_{0:yyyyMMdd_HHmmss}.log" -f (Get-Date))
$argList = @(
  "-m", "quant.i04_cal",
  "--canonical",
  "--out-dir", $out,
  "--workers", "$workers",
  "--cell-list", $allow,
  "--max-runtime-hours", "$maxH",
  "--shutdown-margin-minutes", "$margin"
) + $resume
& $venvPy @argList 2>&1 | Tee-Object -FilePath $log
exit $LASTEXITCODE
