@echo off
setlocal
cd /d "%~dp0"
echo === quant I04-CAL portable runner ===
echo SYNTHETIC ONLY — NO MARKET DATA — NO GEOMETRY WINNER
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0bootstrap.ps1" %*
set ERR=%ERRORLEVEL%
if %ERR% NEQ 0 (
  echo.
  echo Runner exited with code %ERR%. See logs\
  pause
)
endlocal
exit /b %ERR%
