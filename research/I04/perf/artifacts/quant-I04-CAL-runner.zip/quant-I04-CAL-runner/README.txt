quant-I04-CAL-runner — portable One-Command (Windows)
====================================================

SYNTHETIC CALIBRATION ONLY — NO MARKET DATA — NO GEOMETRY WINNER

What this does
--------------
Runs I04-CAL cells on this machine with checkpoints, optional 16h stop,
and a disjoint cell allowlist (ASUS vs OPTIPLEX).

Requirements
------------
- Windows 10/11
- Python 3.11 or 3.12 on PATH (`py -3.12` or `python`)
- ~4+ GB free disk; prefer plugged-in power

First launch (one command)
--------------------------
1. Unzip this folder anywhere (example: Desktop\quant-I04-CAL-runner).
2. Double-click START_WINDOWS.cmd  OR  run it from cmd.
3. Confirm dependency install when asked (user-local venv only).
4. Leave the machine running. Results land in results\ and checkpoints\.

Default: 16h max runtime, 20 min shutdown margin, workers=auto.

Recover results
---------------
Copy the whole folder (or results\ + checkpoints\ + logs\ + reports\)
back to the main PC. On the ASUS repo:

  py -3.12 -m quant.i04_cal.consolidate --out-dir research/I04/calibration/MERGED \
    --source <path-to-optiplex-results> --source <path-to-asus-results> \
    --source research/I04/calibration/I04-CAL-CANONICAL-02

Do not edit JSON checkpoints by hand.
